const express = require("express");
const pessoasController = require('../controllers/pessoaControllers')
const router = express.Router();



router.get('/todos', (req,res) => pessoasController.getAll(req,res))
router.get('/funcionarios', (req,res) => pessoasController.get(req,res))
router.post('/cadastro', (req, res) => pessoasController.create(req, res))
router.put('/reajuste/:id', (req, res) => pessoasController.update(req, res))

module.exports = router
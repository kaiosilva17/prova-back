const Pessoa = require("../models/Pessoa")

const PessoaController = {
    getAll: async (req, res) => {
        res.json(await Pessoa.find())
    },
    create: async (req, res) => {
        try {
            const tipoPessoa = req.body.tipoPessoa;
            const CPF = req.body.cpf;
            const CNPJ = req.body.cnpj;
            const sexo = req.body.sexo;
            const cargo = req.body.cargo

            if (tipoPessoa === "PF" && CPF === undefined) {
                return res.json({ message: 'CPF não informado' });
            } else if (tipoPessoa === "PJ" && CNPJ === undefined) {
                return res.json({ message: 'CNPJ não informado' });
            } else if (tipoPessoa === "PJ" && sexo !== undefined) {
                return res.json({ message: 'O campo sexo só é permitido para Pessoa Física' });
            } else if (tipoPessoa === "PJ" && cargo !== undefined) {
                return res.json({ message: 'O campo cargo só é permitido para Pessoa Física' });
            } else if (CPF !== undefined && CNPJ !== undefined) {
                return res.json({ message: 'Favor informar somente uma opção, CPF ou CNPJ, de acordo com o Tipo de Pessoa' });
            } else {
                return res.json(await Pessoa.create(req.body))
            }
        } catch (error) {
            res.status(400).json(error.message);
        }
    },

    update: async (req, res) => {
        try {
            const pessoa = await Pessoa.findById(req.params.id)
            const reajuste = req.body.reajuste

            const salario_reajustado = pessoa.salario * (reajuste / 100)
            pessoa.salario += salario_reajustado

            await pessoa.save();

            res.json({ message: "Salário reajustado com sucesso", pessoa });
        } catch (error) {
            res.status(404).json(error)
        }
    },

    get: async (req, res) => {
        res.json(await Pessoa.find({ cargo: { $regex: req.query.cargo, $options: "i" } }))
    }
}

module.exports = PessoaController
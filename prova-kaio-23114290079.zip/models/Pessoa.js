const mongoose = require('mongoose')

const Schema = mongoose.Schema({
    tipoPessoa: {
        type: String,
        required: true,
        uppercase: true,
        enum: ["PF", "PJ"]
    },
    nome: {
        type: String,
        maxLength: 20,
        required: true
    },
    salario: {
        type: Number,
        min: 1411,
        required: true
    },
    cpf: {
        type: String,
        match: /^\d{3}\.\d{3}\.\d{3}-\d{2}$/
    },
    cnpj: {
        type: String,
        match: /^\d{2}\.\d{3}\.\d{3}\/\d{4}-\d{2}$/
    },
    sexo: {
        type: String,
        uppercase: true,
        enum: ["F", "M"]
    },
    cargo: {
        type: String,
        enum: ["Estagiario", "Tecnico", "Gerente", "Diretor", "Presidente"]
    },
    reajuste: Number,

})

const Pessoa = mongoose.model('pessoa', Schema)

module.exports = Pessoa